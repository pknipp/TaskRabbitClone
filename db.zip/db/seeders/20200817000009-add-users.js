'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert('Users', [
      {firstName: "John", lastName: "Doe", email: "johndoe@aol.com", phone: 1234567890, hashedPassword: bcrypt.hashSync('password', 10), isAdmin: false},
      {firstName: "Demo", lastName: "User", email: "demo@user.io", phone: null, hashedPassword: bcrypt.hashSync('password', 10), isAdmin: false},
      {firstName: null, lastName: "Thor", email: "thor@aol.com", phone: 1234567890, hashedPassword: bcrypt.hashSync('password', 10), isAdmin: false},
      {firstName: "Lord", lastName: "Voldemort", email: "666@aol.com", phone: null, hashedPassword: bcrypt.hashSync('password', 10), isAdmin: true},
    ], {});
  },

  down: async (queryInterface, Sequelize) => {
     await queryInterface.bulkDelete('Users', null, {});
  }
};
