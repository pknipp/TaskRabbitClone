'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.bulkInsert('Jobs', [
      {userId: 2, taskerId: 2, jobDate: '2020-07-24', details: faker.lorem.sentence()},
      {userId: 2, taskerId: 1, jobDate: '2020-09-24', details: faker.lorem.sentence()},
      {userId: 2, taskerId: 1, jobDate: '2020-07-25', details: faker.lorem.sentence()},
      {userId: 3, taskerId: 1, jobDate: '2020-08-21', details: faker.lorem.sentence()},
      {userId: 1, taskerId: 2, jobDate: '2020-08-24', details: faker.lorem.sentence()},
      {userId: 3, taskerId: 3, jobDate: '2020-07-16', details: faker.lorem.sentence()},
      {userId: 3, taskerId: 5, jobDate: '2020-09-21', details: faker.lorem.sentence()},
      {userId: 1, taskerId: 6, jobDate: '2020-07-16', details: faker.lorem.sentence()},
      {userId: 1, taskerId: 2, jobDate: '2020-07-10', details: faker.lorem.sentence()},
      {userId: 3, taskerId: 4, jobDate: '2020-09-15', details: faker.lorem.sentence()},
      {userId: 1, taskerId: 7, jobDate: '2020-08-22', details: faker.lorem.sentence()},
      {userId: 3, taskerId: 5, jobDate: '2020-09-25', details: faker.lorem.sentence()},
      {userId: 1, taskerId: 4, jobDate: '2020-07-17', details: faker.lorem.sentence()},
      {userId: 3, taskerId: 8, jobDate: '2020-09-11', details: faker.lorem.sentence()},
      {userId: 3, taskerId: 7, jobDate: '2020-09-13', details: faker.lorem.sentence()},
      {userId: 3, taskerId: 7, jobDate: '2020-07-23', details: faker.lorem.sentence()},
      {userId: 3, taskerId: 5, jobDate: '2020-07-29', details: faker.lorem.sentence()},
      {userId: 2, taskerId: 2, jobDate: '2020-07-28', details: faker.lorem.sentence()},
      {userId: 1, taskerId: 1, jobDate: '2020-08-28', details: faker.lorem.sentence()},
      {userId: 1, taskerId: 8, jobDate: '2020-09-20', details: faker.lorem.sentence()},
      {userId: 2, taskerId: 7, jobDate: '2020-09-26', details: faker.lorem.sentence()},
    ], {});
  },

  down: async (queryInterface, Sequelize) => {
     await queryInterface.bulkDelete('Jobs', null, {});
  }
};
